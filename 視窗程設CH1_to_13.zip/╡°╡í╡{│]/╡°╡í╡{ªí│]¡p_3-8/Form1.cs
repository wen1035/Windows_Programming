﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1093305_3_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            int x, y, r, g, b;
            Random rd = new Random();  //使用亂數類別
            Brush b1;
            Graphics g1 = this.CreateGraphics();
            //g1.Clear(Color.White);       //以白色塗滿
            for (int i = 0; i < 10; i++)
            {
                x = 10 + rd.Next(260);  //產生 (10+0 ~ 10+259)的亂數
                y = 10 + rd.Next(260);
                r = rd.Next(256); //產生0~255的亂數
                g = rd.Next(256);
                b = rd.Next(256);
                b1 = new SolidBrush(Color.FromArgb(r, g, b)); //產生亂數顏色畫刷
                g1.FillEllipse(b1, x - 5, y - 5, 10, 10);  //畫圓
            }

        }
    }
}
