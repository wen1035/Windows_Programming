﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1093305_4_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            toolStripMenuItem1.Checked = true;
            toolStripMenuItem4.Checked = true;

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            toolStripMenuItem1.Checked = true;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Gray;
            toolStripMenuItem1.Checked = false;
            toolStripMenuItem2.Checked = true;
            toolStripMenuItem3.Checked = false;

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Silver;
            toolStripMenuItem1.Checked = false;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = true;

        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Black;
            toolStripMenuItem4.Checked = true;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Red;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = true;
            toolStripMenuItem6.Checked = false;

        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Blue;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = true;

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            if (checkBox1.Checked == true)
                textBox1.Text += "英文 ";
            if (checkBox2.Checked == true)
                textBox1.Text += "數學 ";
            if (checkBox3.Checked == true)
                textBox1.Text += "國文 ";
            if (checkBox4.Checked == true)
                textBox1.Text += "物理 ";
            if (checkBox5.Checked == true)
                textBox1.Text += "化學 ";

        }
    }
}
