﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1093305_3_1
{
    using System.Drawing.Drawing2D;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen1 = new Pen(Color.Black, 3);  // 黑色畫筆 粗細為 3
            pen1.DashStyle = DashStyle.Dash; //虛線
            e.Graphics.DrawLine(pen1, 10, 10, 200, 10);
            pen1.DashStyle = DashStyle.DashDot; // 虛線-點線
            e.Graphics.DrawLine(pen1, 10, 40, 200, 40);
            pen1.DashStyle = DashStyle.DashDotDot; // 虛線-點-點線
            e.Graphics.DrawLine(pen1, 10, 70, 200, 70);
            pen1.DashStyle = DashStyle.Dot; //點線
            e.Graphics.DrawLine(pen1, 10, 100, 200, 100);
            pen1.DashStyle = DashStyle.Solid; //實線
            e.Graphics.DrawLine(pen1, 10, 130, 200, 130);



            Pen pen2 = new Pen(Color.Black, 10);  // 黑色畫筆 粗細為 10
            int X = 10;
            int Y = 160;
            pen2.StartCap = LineCap.Flat; // 扁平線條端點。開端
            pen2.EndCap = LineCap.Flat; // 扁平線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.Square; // 方形線條端點。開端
            pen2.EndCap = LineCap.Square; // 方形線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);
            Y = Y + 30;
            pen2.StartCap = LineCap.Round; // 圓形線條端點。開端
            pen2.EndCap = LineCap.Round; // 圓形線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.Triangle; // 三角形線條端點。開端
            pen2.EndCap = LineCap.Triangle; // 三角形線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.SquareAnchor; // 方形錨點線條端點。開端
            pen2.EndCap = LineCap.SquareAnchor; // 方形錨點線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.RoundAnchor; // 圓形錨點線條端點。開端
            pen2.EndCap = LineCap.RoundAnchor; // 圓形錨點線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.DiamondAnchor; // 鑽石形線條端點。開端
            pen2.EndCap = LineCap.DiamondAnchor; // 鑽石形線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

            Y = Y + 30;
            pen2.StartCap = LineCap.ArrowAnchor; // 箭頭形狀線條端點。開端
            pen2.EndCap = LineCap.ArrowAnchor; // 箭頭形狀線條端點。末端
            e.Graphics.DrawLine(pen2, X, Y, X + 200, Y);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Size = new Size(300, 450);
        }
    }
}
