﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;  //File
using System.Collections; //匯入集合函式庫   Stack



namespace _1093305_13_1
{
    public partial class Form1 : Form
    {
        Stack ps = new Stack(); //紀錄復原資訊的堆疊集合
        bool fc = false; //是否來自復原控制鍵的文字改變

        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            richTextBox1.Clear();

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (Path.GetExtension(openFileDialog1.FileName) == ".txt")
                    richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                else
                    richTextBox1.LoadFile(openFileDialog1.FileName);
            }


        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.FileName == "")
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.SaveFile(saveFileDialog1.FileName);
                    openFileDialog1.FileName = saveFileDialog1.FileName;
                }
            }
            else
            {
                richTextBox1.SaveFile(openFileDialog1.FileName);
            }


        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SaveFile(saveFileDialog1.FileName);
                openFileDialog1.FileName = saveFileDialog1.FileName;
            }


        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "RTF檔案(*.rtf); 純文字檔案(*.txt)|*.rtf;*.txt";
            saveFileDialog1.Filter = "RTF檔案|*.rtf";

        }

       
        
    }
}
